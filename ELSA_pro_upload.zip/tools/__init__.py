"""Utility scripts package for ELSA tools.

Adding this file allows invoking scripts with `python -m tools.<module>`.
"""

