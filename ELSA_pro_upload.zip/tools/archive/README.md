Archived utilities

This folder contains experimental or deprecated scripts that were useful during
parameter sweeps and diagnostics but are no longer part of the streamlined workflow.

They are kept for reference and can be resurrected if needed.

